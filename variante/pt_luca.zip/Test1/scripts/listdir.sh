#!/bin/bash

if [ $# -lt 1 ]
then
	exit 2;
else
	fis=$1;
fi

$(dirname $0 | tr -d "scripts")programs/filetypeandsize $fis

if [ $? -eq 1 ]
then
	for sub in "$fis"/*
	do
		$0 $sub
	done
fi
